

import React, { Component } from 'react';
import './App.css';
import { SearchBar,WingBlank,WhiteSpace,Toast } from 'antd-mobile';

function showToast() {
  Toast.info('本功能仅VIP会员可用', 1);
}


class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchText: "",
      currentCity: "上海市",
      zoomSize: 12
    };
  }


  componentDidMount() {
    const { BMap,BMapLib } = window;
    this.map = new BMap.Map("windMap", { enableMapClick: false });
    this.map.centerAndZoom(this.state.currentCity, this.state.zoomSize);
    this.map.disableDoubleClickZoom();
    this.map.enableScrollWheelZoom(true);
    this.map.enableContinuousZoom(true);
    var top_right_conntrol = new window.BMap.ScaleControl({ anchor: window.BMAP_ANCHOR_TOP_RIGHT });
    var top_right_navigation = new window.BMap.NavigationControl({ anchor: window.BMAP_ANCHOR_TOP_RIGHT });
    this.map.addControl(top_right_conntrol);
    this.map.addControl(top_right_navigation);

    // var drawingManager = new BMapLib.DrawingManager(this.map, {
    //   isOpen: false, //是否开启绘制模式
    //   enableDrawingTool: true, //是否显示工具栏
    //   drawingToolOptions: {
    //     anchor: window.BMAP_ANCHOR_BOTTOM_RIGHT, //位置
    //     offset: new BMap.Size(5, 5), //偏离值
    //     scale: 0.8, //工具栏缩放比例
    //     drawingModes: [
    //       window.BMAP_DRAWING_CIRCLE
    //     ]
    //   }
    // });
  }

  onCancel = () => {
    this.map.centerAndZoom(this.state.currentCity, this.state.zoomSize);
  }

  onChange=(value)=>{
    this.setState({
      searchText: value
    });

    if(value.length === 0) {
      this.map.centerAndZoom(this.state.currentCity, this.state.zoomSize);
      return;
    }

    if(value.length >2) {
      const map = this.map;
      const { BMap } = window;
      let that = this;
      var options = {
        onSearchComplete: function(results){
          console.log("the map result is: ",results);
          // 判断状态是否正确
          if (local.getStatus() === 0){
            if(results.getCurrentNumPois() > 0) {
              map.centerAndZoom(results.getPoi(0).point,15);
              map.clearOverlays();
              let circle = new BMap.Circle(results.getPoi(0).point, 500, { fillColor: "#ca4f4f",fillOpacity: 0.6,strokeColor: "#ca4f4f",strokeWeight: 0.1});
              circle.addEventListener("click", e => {
                showToast();
              });
              map.addOverlay(circle);
              var opts = {
                position: results.getPoi(0).point,    // 指定文本标注所在的地理位置
                offset: new BMap.Size(-35, -30)    //设置文本偏移量
              }
              
              var label1 = new BMap.Label("当前区域内", opts);  // 创建文本标注对象
              label1.setStyle({
                color: "white",
                backgroundColor: "transparent",
                border: "0px",
                fontSize: "13px",
                cursor: "pointer"
              });
              label1.addEventListener("click", e => {
                showToast();
              });
              opts.offset = new BMap.Size(-35, 0);

              var label2 = new BMap.Label("有" + Math.ceil(Math.random()*100) + "家企业", opts);  // 创建文本标注对象
              label2.setStyle({
                color: "white",
                backgroundColor: "transparent",
                border: "0px",
                fontSize: "13px",
                cursor: "pointer"
              });
              label2.addEventListener("click", e => {
                showToast();
              });
              map.addOverlay(label1);
              map.addOverlay(label2);
            }
          }
        }
      };
      let local = new BMap.LocalSearch(this.map,options);
      local.search(value);
    }
  }

  render() {
    const height = document.documentElement.clientHeight;
    const mapHeight = height - 62;
    
    return (
      <div>
        <WhiteSpace></WhiteSpace>
        <WingBlank>
          <SearchBar placeholder="请输入查询内容" onChange={this.onChange} onCancel={this.onCancel} value={this.state.searchText} />
        </WingBlank>
        <WhiteSpace></WhiteSpace>
        <div id="windMap" style={{ height: mapHeight }}></div>
        <div id="r-result"></div>
      </div>
    );
  }
}

export default App;
